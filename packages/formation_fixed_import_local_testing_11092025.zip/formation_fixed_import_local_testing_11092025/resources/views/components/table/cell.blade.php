<td {{ $attributes->merge(['class' => 'py-4 text-sm']) }}>
    {{ $slot }}
</td>