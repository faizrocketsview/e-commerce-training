<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class Label extends Fluent
{
    use \Formation\Index\Label;
}