<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class IndexTab extends Fluent
{
    use \Formation\Index\IndexTab;

}