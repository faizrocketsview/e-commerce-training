<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class Index extends Fluent
{
    use \Formation\Index\Index;
}