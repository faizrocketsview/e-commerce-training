<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class Guard extends Fluent
{
    use \Formation\Index\Guard;
}