<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class BulkEdit extends Fluent
{
    use \Formation\Index\BulkEdit;
}