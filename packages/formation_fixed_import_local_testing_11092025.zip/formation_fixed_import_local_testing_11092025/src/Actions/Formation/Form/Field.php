<?php

namespace App\Actions\Formation\Form;

use Illuminate\Support\Fluent;

class Field extends Fluent
{
    use \Formation\Form\Field;
}