<?php

namespace App\Actions\Formation\Form;

use Illuminate\Support\Fluent;

class Tab extends Fluent
{
    use \Formation\Form\Tab;
}