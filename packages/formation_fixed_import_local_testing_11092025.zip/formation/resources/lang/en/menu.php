<?php

return [

    'dashboard' => 'Dashboard',

    'section-1' => 'Section 1',
    'module-1' => 'Module 1',
    'submodule-11' => 'Submodule 1.1',
    'submodule-12' => 'Submodule 1.2',

    'section-2' => 'Section 2',
    'module-2' => 'Module 2',
    'submodule-21' => 'Submodule 2.1',
    'submodule-22' => 'Submodule 2.2',

];