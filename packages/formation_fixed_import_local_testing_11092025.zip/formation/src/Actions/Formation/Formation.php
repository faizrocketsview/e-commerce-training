<?php

namespace App\Actions\Formation;

class Formation
{
    use \Formation\Formation;
}