<?php

namespace App\Actions\Formation\Form;

use Illuminate\Support\Fluent;

class Option extends Fluent
{
    use \Formation\Form\Option;
}