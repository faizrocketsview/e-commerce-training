<?php

namespace App\Actions\Formation\Form;

use Illuminate\Support\Fluent;

class Section extends Fluent
{
    use \Formation\Form\Section;
}