<?php

namespace App\Actions\Formation\Form;

use Illuminate\Support\Fluent;

class Card extends Fluent
{
    use \Formation\Form\Card;
}