<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class GroupBy extends Fluent
{
    use \Formation\Index\GroupBy;
}