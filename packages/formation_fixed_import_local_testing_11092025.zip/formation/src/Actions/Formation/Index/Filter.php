<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class Filter extends Fluent
{
    use \Formation\Index\Filter;
}