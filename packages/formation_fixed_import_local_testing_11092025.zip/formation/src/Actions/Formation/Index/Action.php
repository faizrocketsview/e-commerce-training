<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class Action extends Fluent
{
    use \Formation\Index\Action;
}