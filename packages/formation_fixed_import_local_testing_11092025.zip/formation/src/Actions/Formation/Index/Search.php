<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class Search extends Fluent
{
    use \Formation\Index\Search;
}