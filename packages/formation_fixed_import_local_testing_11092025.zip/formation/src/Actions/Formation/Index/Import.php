<?php

namespace App\Actions\Formation\Index;

use Illuminate\Support\Fluent;

class Import extends Fluent
{
    use \Formation\Index\Import;
}